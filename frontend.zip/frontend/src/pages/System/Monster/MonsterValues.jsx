import React, { useEffect, useState } from 'react'
import api from '../../../api/http'
import { Link } from 'react-router-dom'

export default function MonsterValues(){
  const [list, setList] = useState([])
  useEffect(()=>{
    api.get('/api/system/monster').then(r=>{ if(r.ok) setList(r.data || []) })
  },[])
  return (
    <div className="content">
      <h2>怪物数值</h2>
      {list.map(m=>(
        <div key={m.id} className="card">
          <h3>{m.name}</h3>
          <ul>
            <li>血量: {m.hp} <Link to={`/system/config-editor?category=monster&id=${m.id}&field=hp`}>编辑</Link></li>
            <li>防具: {m.def} <Link to={`/system/config-editor?category=monster&id=${m.id}&field=def`}>编辑</Link></li>
            <li>头盔: {m.helmet} <Link to={`/system/config-editor?category=monster&id=${m.id}&field=helmet`}>编辑</Link></li>
            <li>武器: {m.weapon} <Link to={`/system/config-editor?category=monster&id=${m.id}&field=weapon`}>编辑</Link></li>
          </ul>
        </div>
      ))}
    </div>
  )
}
